var searchData=
[
  ['data_5fwrapper',['Data_Wrapper',['../classuranus_1_1_data___wrapper.html',1,'uranus::Data_Wrapper'],['../classuranus_1_1_data___wrapper.html#ac9388cd654f9b26674588d762f946e37',1,'uranus::Data_Wrapper::Data_Wrapper()']]],
  ['dataset',['DataSet',['../classuranus_1_1_data___wrapper.html#a45527cabbc45b31bf746d70c698611f9',1,'uranus::Data_Wrapper::DataSet()'],['../classuranus_1_1_tensor.html#a828e99ac8adb18d790ef41d53428f011',1,'uranus::Tensor::DataSet()']]],
  ['dynamic',['Dynamic',['../namespaceuranus.html#a1762758a0616a94ae3bdc52c8cb7a806',1,'uranus']]]
];
