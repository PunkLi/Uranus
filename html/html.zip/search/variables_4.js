var searchData=
[
  ['feature_5frows',['feature_rows',['../namespaceuranus.html#a610428f37912c496952c678eee8f0b03',1,'uranus']]]
];
