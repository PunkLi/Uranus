var searchData=
[
  ['setzeromat',['setZeroMat',['../namespaceuranus.html#a8671be44c0784a972283936bcac0eaa4',1,'uranus']]],
  ['solve_5fby_5fnewton',['Solve_by_Newton',['../classuranus_1_1_function.html#a23847145aefea05f4d3184a0922592ff',1,'uranus::Function']]]
];
