var searchData=
[
  ['sample_5fnum',['sample_num',['../namespaceuranus.html#a8e64adf5676f454a0e0d250ca36556c5',1,'uranus']]]
];
