var searchData=
[
  ['dataset',['DataSet',['../classuranus_1_1_data___wrapper.html#a45527cabbc45b31bf746d70c698611f9',1,'uranus::Data_Wrapper::DataSet()'],['../classuranus_1_1_tensor.html#a828e99ac8adb18d790ef41d53428f011',1,'uranus::Tensor::DataSet()']]]
];
