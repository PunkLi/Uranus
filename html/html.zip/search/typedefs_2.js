var searchData=
[
  ['sample',['sample',['../classuranus_1_1_tensor.html#aea8dc8d8769665b6050238bfa2eb8c0b',1,'uranus::Tensor']]],
  ['squarematrix',['SquareMatrix',['../namespaceuranus.html#a2777df10b791b1477a73853c1daf9a95',1,'uranus']]]
];
