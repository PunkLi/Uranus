var searchData=
[
  ['newton_2ecc',['Newton.cc',['../_newton_8cc.html',1,'']]]
];
