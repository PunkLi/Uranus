var searchData=
[
  ['tensor',['Tensor',['../classuranus_1_1_tensor.html#af8a9c5e85b76b184407d7eba7fd51191',1,'uranus::Tensor::Tensor()'],['../classuranus_1_1_tensor.html#af6778dac8e0c1011b9f8736290022560',1,'uranus::Tensor::Tensor(Data_Wrapper &amp;wrapper)']]],
  ['test',['TEST',['../function__unittest_8cc.html#a50ac7fcc404b390fbbd8673e466d159f',1,'function_unittest.cc']]],
  ['trim',['Trim',['../classuranus_1_1_data___wrapper.html#ab87184ac688809ec16d65fd0b2e0a4f1',1,'uranus::Data_Wrapper']]]
];
