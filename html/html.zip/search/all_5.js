var searchData=
[
  ['getfromfile',['getfromfile',['../classuranus_1_1_tensor.html#a0b661cc56fe63da8350d14af8e8bd35e',1,'uranus::Tensor']]]
];
