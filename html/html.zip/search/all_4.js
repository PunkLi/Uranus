var searchData=
[
  ['feature_5frows',['feature_rows',['../namespaceuranus.html#a610428f37912c496952c678eee8f0b03',1,'uranus']]],
  ['fisher_2diris_2ecc',['Fisher-Iris.cc',['../_fisher-_iris_8cc.html',1,'']]],
  ['fisher_2dsonar_2ecc',['Fisher-sonar.cc',['../_fisher-sonar_8cc.html',1,'']]],
  ['fisher_2ecc',['Fisher.cc',['../_fisher_8cc.html',1,'']]],
  ['function',['Function',['../classuranus_1_1_function.html',1,'uranus::Function&lt; Dim &gt;'],['../classuranus_1_1_function.html#a7ca3f33604bb38e9cae1527fedf84fed',1,'uranus::Function::Function()']]],
  ['function_2ehpp',['Function.hpp',['../_function_8hpp.html',1,'']]],
  ['function_5funittest_2ecc',['function_unittest.cc',['../function__unittest_8cc.html',1,'']]]
];
