var searchData=
[
  ['main',['main',['../_newton_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Newton.cc'],['../_fisher-_iris_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-Iris.cc'],['../_fisher-sonar_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-sonar.cc'],['../_fisher_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher.cc']]]
];
