var searchData=
[
  ['buffer',['buffer',['../classuranus_1_1_data___wrapper.html#ab99c6cac241adf42b5611b6fc156fd9c',1,'uranus::Data_Wrapper']]]
];
