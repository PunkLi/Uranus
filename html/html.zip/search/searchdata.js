var indexSectionsWithContent =
{
  0: "bcdefghjmnrstuv",
  1: "dfmst",
  2: "u",
  3: "fmnt",
  4: "dfghjmrstuv",
  5: "bcdefmst",
  6: "dmsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "类型定义"
};

