var searchData=
[
  ['sample',['sample',['../classuranus_1_1_tensor.html#aea8dc8d8769665b6050238bfa2eb8c0b',1,'uranus::Tensor']]],
  ['sample_5fnum',['sample_num',['../namespaceuranus.html#a8e64adf5676f454a0e0d250ca36556c5',1,'uranus']]],
  ['setzeromat',['setZeroMat',['../classuranus_1_1set_zero_mat.html',1,'uranus::setZeroMat'],['../namespaceuranus.html#a8671be44c0784a972283936bcac0eaa4',1,'uranus::setZeroMat(Type rhs)']]],
  ['solve_5fby_5fnewton',['Solve_by_Newton',['../classuranus_1_1_function.html#a23847145aefea05f4d3184a0922592ff',1,'uranus::Function']]],
  ['squarematrix',['SquareMatrix',['../classuranus_1_1_square_matrix.html',1,'uranus::SquareMatrix'],['../namespaceuranus.html#a2777df10b791b1477a73853c1daf9a95',1,'uranus::SquareMatrix()']]],
  ['squarematrix_3c_20dim_20_3e',['SquareMatrix&lt; Dim &gt;',['../classuranus_1_1_square_matrix.html',1,'uranus']]]
];
