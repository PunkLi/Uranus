var searchData=
[
  ['main',['main',['../_newton_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Newton.cc'],['../_fisher-_iris_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-Iris.cc'],['../_fisher-sonar_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-sonar.cc'],['../_fisher_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher.cc']]],
  ['matirx_5fhessian_5f',['matirx_Hessian_',['../classuranus_1_1_function.html#a547a021cd15aad55336c0c78bfe8a5ca',1,'uranus::Function']]],
  ['matirx_5fjacobian_5f',['matirx_Jacobian_',['../classuranus_1_1_function.html#ae4e92825a0c2273b933933d1ccf59db5',1,'uranus::Function']]],
  ['matrix',['Matrix',['../classuranus_1_1_matrix.html',1,'uranus::Matrix'],['../namespaceuranus.html#a873ac2dee6bb9f796ee6f0ed680bf7d8',1,'uranus::Matrix()']]],
  ['matrix_2ehpp',['Matrix.hpp',['../_matrix_8hpp.html',1,'']]],
  ['matrix_5funittest_2ecc',['matrix_unittest.cc',['../matrix__unittest_8cc.html',1,'']]]
];
