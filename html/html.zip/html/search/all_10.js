var searchData=
[
  ['path',['path',['../_fisher-_iris_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;Fisher-Iris.cc'],['../_fisher-sonar_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;Fisher-sonar.cc'],['../_fisher_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;Fisher.cc'],['../_iris-_visual_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;Iris-Visual.cc'],['../knn_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;knn.cc'],['../sonar-visual_8cc.html#a4d455efceee21e97d8e21ee40e9b4a20',1,'path():&#160;sonar-visual.cc']]]
];
