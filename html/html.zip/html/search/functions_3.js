var searchData=
[
  ['evaluation',['Evaluation',['../_fisher_8h.html#a499918fe0ab6e315b151932a54bbd5a9',1,'Evaluation(const uranus::Vector&lt; 1 &gt; W0, const std::vector&lt; uranus::Vector&lt; 1 &gt;&gt; &amp;set):&#160;Fisher.h'],['../knn_8cc.html#ab7076d0dddf5bf55ce48763179c3ba33',1,'Evaluation(std::vector&lt; int &gt; vec, int except):&#160;knn.cc']]]
];
