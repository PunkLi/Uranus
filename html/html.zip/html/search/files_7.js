var searchData=
[
  ['optimizer_2eh',['Optimizer.h',['../_optimizer_8h.html',1,'']]]
];
