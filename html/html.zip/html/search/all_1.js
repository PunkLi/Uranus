var searchData=
[
  ['argw_5f',['argW_',['../_fisher_8h.html#a18374f6459680d0f00f064c593191f30',1,'Fisher.h']]]
];
