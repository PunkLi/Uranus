var searchData=
[
  ['init_5fargw_5f',['init_argW_',['../_fisher_8h.html#a34eb8b19630253ba119ddf3e58a7be94',1,'Fisher.h']]],
  ['init_5fsb_5f',['init_Sb_',['../_fisher_8h.html#ae28d77454476e5af96855846ad794bac',1,'Fisher.h']]],
  ['init_5fw0_5f',['init_W0_',['../_fisher_8h.html#a0f2763467d52750f0b45ccf084f2dd89',1,'Fisher.h']]],
  ['iris',['Iris',['../knn_8cc.html#a3ce59e4572dbb14c2f7bd8b080b6c4aa',1,'knn.cc']]],
  ['iris_2dvisual_2ecc',['Iris-Visual.cc',['../_iris-_visual_8cc.html',1,'']]]
];
