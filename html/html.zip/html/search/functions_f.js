var searchData=
[
  ['tensor',['Tensor',['../classuranus_1_1_tensor.html#a63dac50d1d9fa6b05e97a8d94429b430',1,'uranus::Tensor']]],
  ['test',['TEST',['../function__unittest_8cc.html#a50ac7fcc404b390fbbd8673e466d159f',1,'function_unittest.cc']]],
  ['trim',['Trim',['../classuranus_1_1_data___wrapper.html#a2e84e627a7de15baba7b5909ea483ea5',1,'uranus::Data_Wrapper']]]
];
