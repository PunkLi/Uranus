var searchData=
[
  ['kc',['KC',['../knn_8cc.html#a1c2b2675185d51f5a19d8f09a9a7ee26',1,'knn.cc']]]
];
