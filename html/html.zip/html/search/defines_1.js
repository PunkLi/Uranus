var searchData=
[
  ['dlog_5finfo',['DLOG_INFO',['../log_8h.html#a303ca622420241ec6e6bed04825f93e6',1,'log.h']]],
  ['dlog_5fwarning',['DLOG_WARNING',['../log_8h.html#aad577f533ecc9622a9697d8303b203e6',1,'log.h']]]
];
