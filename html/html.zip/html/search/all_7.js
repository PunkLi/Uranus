var searchData=
[
  ['get_5fmean',['get_mean',['../classuranus_1_1_tensor.html#a335f940aff440625669c1b938351a194',1,'uranus::Tensor']]],
  ['getfromfile',['getfromfile',['../classuranus_1_1_tensor.html#a6f2d26e3f4f3e763004479da1e4b4b97',1,'uranus::Tensor']]],
  ['glogwrapper',['GLogWrapper',['../classuranus_1_1_g_log_wrapper.html',1,'uranus::GLogWrapper'],['../classuranus_1_1_g_log_wrapper.html#accfdeab41c4f72482e2fc6b78f30f105',1,'uranus::GLogWrapper::GLogWrapper()']]],
  ['gradient',['gradient',['../un-constrained_8hpp.html#a78193407770997f2c18b045fa8201b9a',1,'un-constrained.hpp']]]
];
