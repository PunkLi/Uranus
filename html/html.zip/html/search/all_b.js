var searchData=
[
  ['k_5ffold_5fcrossvalidation',['k_fold_crossValidation',['../classuranus_1_1_tensor.html#abc4cc5a9ee8fb824717fef24945f8d61',1,'uranus::Tensor']]],
  ['k_5fknn',['K_knn',['../knn_8cc.html#ad6e48c4a03871913ae7199fd767a6de0',1,'knn.cc']]],
  ['kc',['KC',['../knn_8cc.html#a1c2b2675185d51f5a19d8f09a9a7ee26',1,'knn.cc']]],
  ['knn_2ecc',['knn.cc',['../knn_8cc.html',1,'']]],
  ['knn_5fsolver',['knn_solver',['../knn_8cc.html#aa404e3aa2e02e0b7c1a4a5dd245ad76b',1,'knn.cc']]]
];
