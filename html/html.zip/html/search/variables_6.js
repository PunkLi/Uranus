var searchData=
[
  ['matirx_5fhessian_5f',['matirx_Hessian_',['../classuranus_1_1_function.html#a547a021cd15aad55336c0c78bfe8a5ca',1,'uranus::Function']]],
  ['matirx_5fjacobian_5f',['matirx_Jacobian_',['../classuranus_1_1_function.html#ae4e92825a0c2273b933933d1ccf59db5',1,'uranus::Function']]],
  ['mean',['mean',['../_fisher_8cc.html#a18c0889dd87000b3a0e0187c7f72cc8a',1,'Fisher.cc']]]
];
