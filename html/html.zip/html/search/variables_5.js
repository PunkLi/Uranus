var searchData=
[
  ['k_5fknn',['K_knn',['../knn_8cc.html#ad6e48c4a03871913ae7199fd767a6de0',1,'knn.cc']]]
];
