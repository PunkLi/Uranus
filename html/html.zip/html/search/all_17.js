var searchData=
[
  ['_7eglogwrapper',['~GLogWrapper',['../classuranus_1_1_g_log_wrapper.html#ab6f2b043130d9db4e69d9d74475e8bab',1,'uranus::GLogWrapper']]]
];
