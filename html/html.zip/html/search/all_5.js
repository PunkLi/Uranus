var searchData=
[
  ['e',['E',['../sonar-visual_8cc.html#acea65c39dac8dcaadc5ee2c8b1219463',1,'sonar-visual.cc']]],
  ['evaluation',['Evaluation',['../_fisher_8h.html#a499918fe0ab6e315b151932a54bbd5a9',1,'Evaluation(const uranus::Vector&lt; 1 &gt; W0, const std::vector&lt; uranus::Vector&lt; 1 &gt;&gt; &amp;set):&#160;Fisher.h'],['../knn_8cc.html#ab7076d0dddf5bf55ce48763179c3ba33',1,'Evaluation(std::vector&lt; int &gt; vec, int except):&#160;knn.cc']]],
  ['exp_5fnum_5f',['exp_num_',['../classuranus_1_1_function.html#ae7d1208531526393975ec41fb9cda8bb',1,'uranus::Function']]]
];
