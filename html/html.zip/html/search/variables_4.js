var searchData=
[
  ['feature_5frows',['feature_rows',['../_fisher_8cc.html#a90983e2ef3031008f7626563bcdd9827',1,'Fisher.cc']]]
];
