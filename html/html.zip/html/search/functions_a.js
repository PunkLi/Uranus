var searchData=
[
  ['main',['main',['../_fisher-_iris_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-Iris.cc'],['../_fisher-sonar_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher-sonar.cc'],['../_fisher_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fisher.cc'],['../_iris-_visual_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Iris-Visual.cc'],['../knn_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;knn.cc'],['../_newton_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Newton.cc'],['../sonar-visual_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;sonar-visual.cc']]],
  ['multi_5fdiscriminant',['Multi_Discriminant',['../_fisher_8h.html#a76006c30e1b44a09b5240016b1de195f',1,'Fisher.h']]]
];
