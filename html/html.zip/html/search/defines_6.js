var searchData=
[
  ['sb_5f',['Sb_',['../_fisher_8h.html#afb97aa1f6519db1c3093b1f27638b305',1,'Fisher.h']]],
  ['show_5ftest_5fset',['SHOW_TEST_SET',['../_iris-_visual_8cc.html#aa6fa8d162e7b4991f5adb590504fc21e',1,'SHOW_TEST_SET():&#160;Iris-Visual.cc'],['../sonar-visual_8cc.html#aa6fa8d162e7b4991f5adb590504fc21e',1,'SHOW_TEST_SET():&#160;sonar-visual.cc']]],
  ['show_5ftrain_5fset',['SHOW_TRAIN_SET',['../_iris-_visual_8cc.html#a4127f2f08393fcb435fb36732648702a',1,'SHOW_TRAIN_SET():&#160;Iris-Visual.cc'],['../sonar-visual_8cc.html#a4127f2f08393fcb435fb36732648702a',1,'SHOW_TRAIN_SET():&#160;sonar-visual.cc']]]
];
