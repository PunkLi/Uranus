var searchData=
[
  ['leave_5fone_5fout_5fvalidation',['leave_one_out_validation',['../classuranus_1_1_tensor.html#a067d2b11f55f0773b1de06c16441cc3a',1,'uranus::Tensor']]],
  ['linear_5fsearch',['Linear_search',['../un-constrained_8hpp.html#a7c39096e623fa8879676a100bbb19a4a',1,'un-constrained.hpp']]]
];
