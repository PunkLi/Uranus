var searchData=
[
  ['k_5ffold_5fcrossvalidation',['k_fold_crossValidation',['../classuranus_1_1_tensor.html#abc4cc5a9ee8fb824717fef24945f8d61',1,'uranus::Tensor']]],
  ['knn_5fsolver',['knn_solver',['../knn_8cc.html#aa404e3aa2e02e0b7c1a4a5dd245ad76b',1,'knn.cc']]]
];
