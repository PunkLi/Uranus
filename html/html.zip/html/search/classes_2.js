var searchData=
[
  ['glogwrapper',['GLogWrapper',['../classuranus_1_1_g_log_wrapper.html',1,'uranus']]]
];
