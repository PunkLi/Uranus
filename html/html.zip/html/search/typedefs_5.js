var searchData=
[
  ['tensor',['tensor',['../knn_8cc.html#afd9377becc7630ffae521a07b51e5eb3',1,'knn.cc']]],
  ['tensortype',['TensorType',['../classuranus_1_1_tensor.html#a40c170edef3571692af12e0c40ca0e51',1,'uranus::Tensor']]]
];
