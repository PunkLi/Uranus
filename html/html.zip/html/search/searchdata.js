var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw~",
  1: "dfgmst",
  2: "lu",
  3: "cfiklmnostu",
  4: "_cdefghjklmnorstuv~",
  5: "bcdefkmpstv",
  6: "cdkmstv",
  7: "adilnrsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "类型定义",
  7: "宏定义"
};

