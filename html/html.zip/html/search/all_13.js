var searchData=
[
  ['tensor',['Tensor',['../classuranus_1_1_tensor.html',1,'uranus::Tensor&lt; feature_rows &gt;'],['../classuranus_1_1_tensor.html#afa55a7558d7019e06aef639ea124ec12',1,'uranus::Tensor::tensor()'],['../classuranus_1_1_tensor.html#a63dac50d1d9fa6b05e97a8d94429b430',1,'uranus::Tensor::Tensor(const Data_Wrapper&lt; feature_rows &gt; &amp;wrapper, const std::vector&lt; int &gt; class_size, bool ishow=false)'],['../knn_8cc.html#afd9377becc7630ffae521a07b51e5eb3',1,'tensor():&#160;knn.cc']]],
  ['tensor_2ehpp',['Tensor.hpp',['../_tensor_8hpp.html',1,'']]],
  ['tensortype',['TensorType',['../classuranus_1_1_tensor.html#a40c170edef3571692af12e0c40ca0e51',1,'uranus::Tensor']]],
  ['test',['TEST',['../function__unittest_8cc.html#a50ac7fcc404b390fbbd8673e466d159f',1,'function_unittest.cc']]],
  ['trim',['Trim',['../classuranus_1_1_data___wrapper.html#a2e84e627a7de15baba7b5909ea483ea5',1,'uranus::Data_Wrapper']]]
];
