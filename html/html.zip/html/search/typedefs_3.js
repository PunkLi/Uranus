var searchData=
[
  ['matrix',['Matrix',['../namespaceuranus.html#a873ac2dee6bb9f796ee6f0ed680bf7d8',1,'uranus']]]
];
