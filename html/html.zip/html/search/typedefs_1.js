var searchData=
[
  ['dataset',['DataSet',['../classuranus_1_1_data___wrapper.html#af980eef660c7e39ec11d3694cfc38c30',1,'uranus::Data_Wrapper::DataSet()'],['../classuranus_1_1_tensor.html#a5945aae77193f94571d7e827cf6347ff',1,'uranus::Tensor::DataSet()']]]
];
