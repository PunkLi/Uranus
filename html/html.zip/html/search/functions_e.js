var searchData=
[
  ['setzero',['setZero',['../namespaceuranus.html#a86faff04df01ca766621290453e54130',1,'uranus']]],
  ['solve_5fby_5fnewton',['Solve_by_Newton',['../classuranus_1_1_function.html#a23847145aefea05f4d3184a0922592ff',1,'uranus::Function']]],
  ['steepest_5fdescent',['steepest_descent',['../un-constrained_8hpp.html#ad0e446c71c4d312a460c9356965159d9',1,'un-constrained.hpp']]]
];
