var searchData=
[
  ['sample',['sample',['../knn_8cc.html#a1ea632cdfa5d1ec93525ae75a30abf74',1,'knn.cc']]],
  ['sample_5fset',['sample_set',['../classuranus_1_1_tensor.html#a82061fb794d957e9613e28e2dcc52d12',1,'uranus::Tensor::sample_set()'],['../knn_8cc.html#aac7c90b321dd16692378b7a13fd17ee9',1,'sample_set():&#160;knn.cc']]],
  ['sampletype',['sampleType',['../classuranus_1_1_tensor.html#a581081c7c99caf18b1805406ba87804e',1,'uranus::Tensor']]],
  ['squarematrix',['SquareMatrix',['../namespaceuranus.html#a2777df10b791b1477a73853c1daf9a95',1,'uranus']]]
];
