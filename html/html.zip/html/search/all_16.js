var searchData=
[
  ['w0_5f',['W0_',['../_fisher_8h.html#ae0729d5983e55bf8d3e5be94f2c5ef5e',1,'Fisher.h']]]
];
