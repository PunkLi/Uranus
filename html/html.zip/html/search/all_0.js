var searchData=
[
  ['_5fsum',['_sum',['../classuranus_1_1_tensor.html#a9bb6f4d74a01502169a67cce00ac7e70',1,'uranus::Tensor']]]
];
