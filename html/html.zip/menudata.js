/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"首页",url:"index.html"},
{text:"命名空间",url:"namespaces.html",children:[
{text:"命名空间列表",url:"namespaces.html"},
{text:"命名空间成员",url:"namespacemembers.html",children:[
{text:"全部",url:"namespacemembers.html"},
{text:"函数",url:"namespacemembers_func.html"},
{text:"变量",url:"namespacemembers_vars.html"},
{text:"类型定义",url:"namespacemembers_type.html"}]}]},
{text:"类",url:"annotated.html",children:[
{text:"类列表",url:"annotated.html"},
{text:"类索引",url:"classes.html"},
{text:"类成员",url:"functions.html",children:[
{text:"全部",url:"functions.html"},
{text:"函数",url:"functions_func.html"},
{text:"变量",url:"functions_vars.html"},
{text:"类型定义",url:"functions_type.html"}]}]},
{text:"文件",url:"files.html",children:[
{text:"文件列表",url:"files.html"},
{text:"文件成员",url:"globals.html",children:[
{text:"全部",url:"globals.html"},
{text:"函数",url:"globals_func.html"}]}]}]}
